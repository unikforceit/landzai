<?php
    echo '<div class="widget tags-widget">
                <h3 class="widget-title">Popular Tags</h3>
                <ul>
                    <li><a href="#">Ecommerce</a></li>
                    <li><a href="#">Corporate</a></li>
                    <li><a href="#">Shop</a></li>
                    <li><a href="#">Real Estate</a></li>
                    <li><a href="#">Agency</a></li>
                    <li><a href="#">Marketing</a></li>
                </ul>
            </div>';