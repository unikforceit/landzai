<?php
    echo '<div class="widget popular-news-widget">
            <h3 class="widget-title">Popular News</h3>
            <ul class="posts-list">
                <li class="single-post">
                    <div class="media ">
                        <div class="post-thumbnail mr-4">
                            <a href="#">'.get_that_image($settings['image1']).'</a>
                        </div>
                        <div class="media-body">
                          <h4 class="post-time"> <span class="date">15</span> Jan, 2020</h4>
                          <h3 class="post-title"><a href="single-blog.html">Lorem ipsum dolor sit amet, consectetur </a></h3>
                        </div>
                    </div>
                </li>
                <li class="single-post">
                    <div class="media ">
                        <div class="post-thumbnail mr-4">
                            <a href="#">'.get_that_image($settings['image2']).'</a>
                        </div>
                        <div class="media-body">
                          <h4 class="post-time"> <span class="date">15</span> Jan, 2020</h4>
                          <h3 class="post-title"><a href="single-blog.html">Lorem ipsum dolor sit amet, consectetur </a></h3>
                        </div>
                    </div>
                </li>
                <li class="single-post">
                    <div class="media ">
                        <div class="post-thumbnail mr-4">
                            <a href="#">'.get_that_image($settings['image3']).'</a>
                        </div>
                        <div class="media-body">
                          <h4 class="post-time"> <span class="date">15</span> Jan, 2020</h4>
                          <h3 class="post-title"><a href="single-blog.html">Lorem ipsum dolor sit amet, consectetur </a></h3>
                        </div>
                    </div>
                </li>
                <li class="single-post">
                    <div class="media ">
                        <div class="post-thumbnail mr-4">
                            <a href="#">'.get_that_image($settings['image4']).'</a>
                        </div>
                        <div class="media-body">
                          <h4 class="post-time"> <span class="date">15</span> Jan, 2020</h4>
                          <h3 class="post-title"><a href="single-blog.html">Lorem ipsum dolor sit amet, consectetur </a></h3>
                        </div>
                    </div>
                </li>
            </ul>
        </div>';