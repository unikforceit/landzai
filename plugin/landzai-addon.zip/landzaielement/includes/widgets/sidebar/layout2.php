<?php
    echo ' <div class="widget category-widget">
            <h3 class="widget-title">News Categories</h3>
            <ul>
                <li><a href="#">Fashion <span>(23)</span></a></li>
                <li><a href="#">Hobies <span>(5)</span></a></li>
                <li><a href="#">Lifestyle <span>(45)</span></a></li>
                <li><a href="#">Decoration <span>(3)</span></a></li>
                <li><a href="#">Corporate <span>(12)</span></a></li>
                <li><a href="#">Real State <span>(20)</span></a></li>
            </ul>
        </div>';