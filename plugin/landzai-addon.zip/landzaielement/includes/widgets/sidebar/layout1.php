<?php
    echo '<div class="widget search-widget">
            <h3 class="widget-title">Search Post</h3>
            <form action="#">
                <div class="form-group mb-0">
                  <input type="text" class="form-control" id="search" placeholder="Search Post"  />
                  <button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
                </div>
            </form>
        </div>';