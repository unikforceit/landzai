<?php
    echo ' <div class="widget archives-widget">
                <h3 class="widget-title">Archives</h3>
                <ul>
                    <li><a href="#">January- 2020 <span>(20)</span></a></li>
                    <li><a href="#">February- 2020 <span>(34)</span></a></li>
                    <li><a href="#">March- 2020 <span>(56)</span></a></li>
                    <li><a href="#">April- 2020 <span>(76)</span></a></li>
                    <li><a href="#">May- 2020 <span>(12)</span></a></li>
                    <li><a href="#">June- 2020 <span>(45)</span></a></li>
                </ul>
            </div>';